# Screenshots Folder

This folder is reserved for screenshots related to testing, such as UI screenshots, bug evidence, or test result captures.

Please add relevant images here.
