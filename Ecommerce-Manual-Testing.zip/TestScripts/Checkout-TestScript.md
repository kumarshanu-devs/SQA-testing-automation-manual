# Checkout Feature - Manual Test Script

## Objective
Verify that users can complete the checkout process successfully.

## Test Steps
1. Proceed to checkout from the cart.
2. Enter shipping address and payment details.
3. Review order summary.
4. Submit the order.
5. Confirm order success message and order number.
6. Verify order details in user account/orders page.
